from flask import Flask, render_template, request, jsonify
import os
from audio_handler import start_audio_recording, stop_audio_recording, convert_speech_to_text, convert_text_to_speech, play_audio
import text_extraction
import email_handler
from run_falcon import process_falcon_prompt 

app = Flask(__name__)

latest_response = ""

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/welcome')
def welcome():
    return render_template('welcome.html')

@app.route('/main')
def main():
    return render_template('main.html')

@app.route('/start_recording', methods=['POST'])
def start_recording():
    try:
        start_audio_recording()
        print("Audio recording started.")
        return jsonify(success=True), 200
    except Exception as e:
        print(f"Error starting audio recording: {e}")
        return jsonify(error=str(e)), 500

@app.route('/stop_recording', methods=['POST'])
def stop_recording():
    try:
        file_path = stop_audio_recording()
        print(f"Audio recording stopped. File saved at {file_path}")
        return jsonify(success=True, file_path=file_path), 200
    except Exception as e:
        print(f"Error stopping audio recording: {e}")
        return jsonify(error=str(e)), 500

@app.route('/chatbot_chain', methods=['POST'])
def chatbot_chain():
    global latest_response
    try:
        
        print("Converting speech to text...")
        text = convert_speech_to_text(r'D:\FYP UI\input.wav') 
        print(f"Speech converted to text: {text}")
        
        
        print("Processing text with Falcon model...")
        response_text = process_falcon_prompt(text)
        print(f"Falcon model response: {response_text}")

        latest_response = response_text
        
        
        print("Converting response text to speech and playing audio...")
        play_audio(response_text)
        print("Audio played successfully.")
        
        return jsonify(success=True), 200
    except Exception as e:
        print(f"Error in chatbot chain: {e}")
        return jsonify(error=str(e)), 500

@app.route('/upload_image', methods=['POST'])
def upload_image():
    global latest_response
    if 'file' not in request.files:
        print("No file provided in upload_image.")
        return jsonify(error="No file provided"), 400

    file = request.files['file']
    if file.filename == '':
        print("No selected file in upload_image.")
        return jsonify(error="No selected file"), 400

    file_path = os.path.join('uploads', file.filename)
    file.save(file_path)
    print(f"File uploaded successfully: {file_path}")

   
    print("Extracting text from image...")
    extracted_text = text_extraction.extract_text_from_image(file_path)
    print(f"Extracted text: {extracted_text}")

    
    response_text = process_falcon_prompt(extracted_text)
    print(f"Falcon model response: {response_text}")

    latest_response = response_text

    
    play_audio(response_text)
    print("Audio played successfully.")

    return jsonify(success=True, response=response_text), 200

@app.route('/send_email', methods=['POST'])
def send_email():
    global latest_response
    data = request.get_json()
    email = data.get('email')
    #response = data.get('response')

    if not email:
        print("No email provided in send_email.")
        return jsonify(error="No email provided"), 400

    try:
        print(f"Sending email to {email} with response: {latest_response}")
        email_handler.send_email(email, "LibraBot Response", latest_response)
        response_message = "Email sent successfully"
        print(response_message)
        return jsonify(message=response_message), 200
    except Exception as e:
        print(f"Failed to send email: {e}")
        return jsonify(error=str(e)), 500

if __name__ == '__main__':
    app.run(debug=True)
