import pyaudio
import wave
import threading
import speech_recognition as sr
from gtts import gTTS
import os
import grpc
import audio2face_pb2_grpc 
import audio2face_pb2
import numpy as np
import pyttsx3
import soundfile
import time
from datetime import datetime
from run_falcon import process_falcon_prompt  

audio = pyaudio.PyAudio()
stream = None
frames = []
is_recording = False
recording_thread = None

def get_audio2face_client():
    channel = grpc.insecure_channel('localhost:50051') 
    stub = audio2face_pb2_grpc.Audio2FaceStub(channel)
    return stub

def send_audio_stream(audio_file_path, player_name):
    url = 'localhost:50051'
    stub = get_audio2face_client()
    
    
    data, samplerate = soundfile.read(audio_file_path, dtype="float32")
    print(f"Audio file read with samplerate: {samplerate}, data shape: {data.shape}")

    
    if len(data.shape) > 1:
        data = np.average(data, axis=1)

    chunk_size = samplerate // 10 
    sleep_between_chunks = 0.04 
    block_until_playback_is_finished = True

    with grpc.insecure_channel(url) as channel:
        stub = audio2face_pb2_grpc.Audio2FaceStub(channel)

        def make_generator():
            start_marker = audio2face_pb2.PushAudioRequestStart(
                samplerate=samplerate,
                instance_name=player_name,
                block_until_playback_is_finished=block_until_playback_is_finished,
            )
            
            yield audio2face_pb2.PushAudioStreamRequest(start_marker=start_marker)
            
            for i in range(len(data) // chunk_size + 1):
                time.sleep(sleep_between_chunks)
                chunk = data[i * chunk_size : i * chunk_size + chunk_size]
                yield audio2face_pb2.PushAudioStreamRequest(audio_data=chunk.astype(np.float32).tobytes())

        request_generator = make_generator()
        print("Sending audio data...")
        response = stub.PushAudioStream(request_generator)
        if response.success:
            print("SUCCESS")
        else:
            print(f"ERROR: {response.message}")
    print("Closed channel")

def start_audio_recording():
    global stream, frames, is_recording, recording_thread

    if is_recording:
        raise Exception("Recording is already in progress")

    frames = []
    stream = audio.open(format=pyaudio.paInt16,
                        channels=1,
                        rate=44100,
                        input=True,
                        frames_per_buffer=1024)
    
    is_recording = True
    recording_thread = threading.Thread(target=record_audio)
    recording_thread.start()
    print("Audio recording started.")

def record_audio():
    global stream, frames, is_recording

    while is_recording:
        data = stream.read(1024)
        frames.append(data)
    print("Recording audio...")

def stop_audio_recording():
    global stream, frames, is_recording, recording_thread

    if not is_recording:
        raise Exception("No recording in progress")

    is_recording = False
    recording_thread.join()
    
    stream.stop_stream()
    stream.close()
    
    file_path = 'input.wav'
    wf = wave.open(file_path, 'wb')
    wf.setnchannels(1)
    wf.setsampwidth(audio.get_sample_size(pyaudio.paInt16))
    wf.setframerate(44100)
    wf.writeframes(b''.join(frames))
    wf.close()
    
    print(f"Audio recording stopped. File saved at {file_path}")
    print(f"File last modified: {datetime.fromtimestamp(os.path.getmtime(file_path))}")
    return file_path

# def convert_speech_to_text(audio_path):
#     recognizer = sr.Recognizer()

#     print(f"Processing audio file: {audio_path}")
#     print(f"File last modified before reading: {datetime.fromtimestamp(os.path.getmtime(audio_path))}")

#     with sr.AudioFile(audio_path) as source:
#         audio_data = recognizer.record(source)

#     try:
#         text = recognizer.recognize_google(audio_data)
#         if text:
#             print(f"Query sent by user: {text}")
#             response = process_falcon_prompt(text)
#             print(f"Response from Falcon: {response}")
#             return response
#         return ""
#     except sr.UnknownValueError:
#         print("Speech Recognition could not understand the audio")
#         return ""
#     except sr.RequestError as e:
#         print(f"Could not request results from Speech Recognition service; {e}")
#         return ""


def convert_speech_to_text(audio_path):
    recognizer = sr.Recognizer()

    print(f"Processing audio file: {audio_path}")
    print(f"File last modified before reading: {datetime.fromtimestamp(os.path.getmtime(audio_path))}")

    
    with open(audio_path, 'rb') as f:
        pass

    with sr.AudioFile(audio_path) as source:
        audio_data = recognizer.record(source)

    try:
        text = recognizer.recognize_google(audio_data)
        if text:
            print(f"Query sent by user: {text}")
            response = process_falcon_prompt(text)
            print(f"Response from Falcon: {response}")
            return response
        return ""
    except sr.UnknownValueError:
        print("Speech Recognition could not understand the audio")
        return ""
    except sr.RequestError as e:
        print(f"Could not request results from Speech Recognition service; {e}")
        return ""


def convert_text_to_speech(text, output_path='output.wav'):
    tts = gTTS(text, lang='en', tld='com')  
    tts.save(output_path)
    print(f"Text converted to speech and saved at {output_path}")
    return output_path

def play_audio(text):
    audio_file_path = convert_text_to_speech(text) 
    player_name = r'/World/audio2face/PlayerStreaming'
    send_audio_stream(audio_file_path, player_name)
    print(f"Audio played from {audio_file_path}")
