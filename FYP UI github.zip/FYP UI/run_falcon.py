
import json
import os
from pprint import pprint
import bitsandbytes as bnb
import torch
import torch.nn as nn
import transformers
from datasets import load_dataset
from huggingface_hub import notebook_login
from peft import (
    LoraConfig,
    PeftConfig,
    PeftModel,
    get_peft_model,
    prepare_model_for_kbit_training
)
from transformers import (
    AutoConfig,
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig
)

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

#os.environ["HUGGINGFACEHUB_API_TOKEN"] = "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"

base_model_path = r"E:\\EHAB-MODEL\\cache\\models--vilsonrodrigues--falcon-7b-instruct-sharded\\snapshots\\0e7ea20c0bfd0665eaf3835f1efd12a0e8f02d90"
#adapter_model_path = r"E:\\EHAB-MODEL\\adapter_model"

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_use_double_quant=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16
)

PEFT_MODEL = r"E:\\EHAB-MODEL\\adapter_model"

def load_falcon_model():
    try:
        print("Loading PEFT configuration...")
        config = PeftConfig.from_pretrained(PEFT_MODEL)
        print("PEFT configuration loaded.")

        print("Loading model...")
        model = AutoModelForCausalLM.from_pretrained(
            config.base_model_name_or_path,
            return_dict=True,
            quantization_config=bnb_config,
            device_map="auto",
            trust_remote_code=True,
            use_safetensors=True
        )
        print("Model loaded successfully.")

        tokenizer = AutoTokenizer.from_pretrained(config.base_model_name_or_path)
        tokenizer.pad_token = tokenizer.eos_token

        Newmodel = PeftModel.from_pretrained(model, PEFT_MODEL)
        print("PEFT model loaded successfully.")

        generation_config = Newmodel.generation_config
        generation_config.max_new_tokens = 100
        generation_config.temperature = 0.7
        generation_config.top_p = 0.7
        generation_config.num_return_sequences = 1
        generation_config.pad_token_id = tokenizer.eos_token_id
        generation_config.eos_token_id = tokenizer.eos_token_id

        return tokenizer, Newmodel, generation_config

    except Exception as e:
        print(f"Error during model loading or processing: {e}")
        return None, None, None

if os.environ.get("WERKZEUG_RUN_MAIN") == "true":
    tokenizer, Newmodel, generation_config = load_falcon_model()
else:
    tokenizer, Newmodel, generation_config = None, None, None

device = "cuda:0" if torch.cuda.is_available() else "cpu"

def process_falcon_prompt(prompt):
    if tokenizer and Newmodel:
        encoding = tokenizer(prompt, return_tensors="pt").to(device)
        with torch.inference_mode():
            outputs = Newmodel.generate(
                input_ids=encoding.input_ids,
                attention_mask=encoding.attention_mask,
                generation_config=generation_config
            )
        return tokenizer.decode(outputs[0], skip_special_tokens=True)
    else:
        print("Model is not loaded.")
        return "Model is not available at the moment."
