from PIL import Image
import pytesseract


pytesseract.pytesseract.tesseract_cmd = r'C:\OCR\ocr\tesseract.exe' 

def extract_text_from_image(image_path):

    try:
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img)
        return text
    except Exception as e:
        print(f"Failed to extract text from image: {e}")
        return ""
